%% myo_mex.m  Help file for myo_mex MEX file
%
% myo_mex  Provides is a MEX wrapper for Myo SDK
%   This MEX function is provided along with an m-code class wrapper named
%   MyoMex. Detailed information on how to use this low-level MEX interface
%   can be found in the implementation of this class or by reading through
%   the source code in myo_mex.cpp and myo_class.hpp
%
%   Created with: 
%   MATLAB R2013a
%   Platform: win64
%   Microsoft SDK 7.1

%   MEX File function.
